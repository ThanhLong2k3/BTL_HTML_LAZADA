var list =  document.getElementsByClassName('silde-img');
var index = 0;
for(x of list){
    x.style.display= 'none'; 
}
list[index].style.display= 'block';
function showL() {
    for(x of list){
        x.style.display= 'none';
    }
    if(index == 0) index =  list.length -1;
    else index = index -1;
    list[index].style.display= 'block';
    setTimeout(showL, 2000); 
}

function showR() {
    for(x of list){
        x.style.display= 'none';
    }
    if(index == list.length -1) index =  0;
    else index = index + 1;
    list[index].style.display= 'block';
    
}

 setTimeout(showL, 2000);
 


  
  function tang(){
    var sl=document.getElementById('sl').textContent;
    sl++;
    document.getElementById('sl').textContent=sl;
  }
  function giam(){
    var sl=document.getElementById('sl').textContent;
    if(sl>0)
    {
      sl--;
    }
    else
    {
      sl==0;
    }
    document.getElementById('sl').textContent=sl;
  }


 



 